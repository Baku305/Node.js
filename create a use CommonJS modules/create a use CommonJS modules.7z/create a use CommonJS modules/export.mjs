
export function printName(params) {
 console.log(params)
}
