import { printName } from "./export.mjs"

const myName = "francesco"

printName(myName)