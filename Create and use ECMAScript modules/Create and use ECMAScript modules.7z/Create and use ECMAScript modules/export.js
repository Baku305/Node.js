const printName = (name) => console.log(name);

module.exports = printName