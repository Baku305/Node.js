const printName = require ("./export.js")

printName("francesco")